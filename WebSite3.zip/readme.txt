

We implemented a website that can be used to search by National ID. in history.aspx (that already attched in the folder we can do browsing for any vaccination by using Google Chrom or internet Explorer.Vaccination history page contain DATE,PLACE and Clinic.